<?php
session_start();


require_once('dbconnection.php');
include("nav.php")
?>
    </div>
    <div id="hero">
        <div id="hero-content">
            <div id="content">
			
			<?php
			if(empty($_SESSION['name']))
			{	
				echo("<h2>VISITOR</h2>");
									
                echo '<h1>Welcome To Health Care Service Centre</h1>';
                echo '<p>Make online bookings for your Covid testing and Screening</p>';
			}else
			{
				echo"<h1>";
				echo $_SESSION['name']." ".$_SESSION['surname'];
				echo"</h1>";				
                echo '<h1>Welcome To Health Care Service Centre</h1>';
                echo '<p>Make online bookings for your Covid testing and Screening</p>';
			}
			?>
            </div>
        </div>
    </div>
    <div id="news">
        <div class="container">
            <div id="latest-news">
              
                

				
		<div class="right-image-post"> <!--Second box starts here-->
            <div class="row">
              <div class="col-md-6">
                <div class="left-text">
                  <h4>COVID TESTING</h4>
                  <p>
                    </p>Two kinds of tests are available for COVID-19: viral tests and antibody tests.</p>
					<ul>
					<li>A viral test tells you if you have a current infection.</li>
					<li>An antibody test might tell you if you had a past infection.</li>
						</ul>
                  </p>
                  <div class="white-button">
                    <a href="https://www.cdc.gov/coronavirus/2019-ncov/symptoms-testing/testing.html">Read More</a>
                  </div>
                </div>
              </div>
              <div class="col-md-6">
                <div class="right-image">
                  <img src="assets/images/testing.jpg" alt="" />
                </div>
              </div>
            </div>
          </div><!--end of second box-->
					
					
               
                <hr>
            
            </div>
        </div>
    </div>
<!-- Footer -->
<footer class="page-footer font-small mdb-color lighten-3 pt-4">


  <!-- Copyright -->
  © 2020 Copyright:
   
 
  <!-- Copyright -->

</footer>
<!-- Footer -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/script.js"></script>
	
	
	
	
	
	
	
	
	<!--for maps-->
	<script>
function myMap() {
var mapProp= {
  center:new google.maps.LatLng(-26.2041, 28.0473),
  zoom:5,
};
var map = new google.maps.Map(document.getElementById("googleMap"),mapProp);
	
	
	
        // The marker, positioned at Uluru
        const marker = new google.maps.Marker({
          position: (-26.2041, 28.0473),
          map: mapProp,
        });	
}
</script>

<script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY&callback=myMap"></script>
</body>

</html>